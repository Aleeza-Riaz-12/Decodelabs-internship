# ==========================================================
# DATA SCIENCE PROJECT 2
# FRAUD DETECTION PIPELINE
# PART 1 : Data Loading, Data Cleaning & Feature Engineering
# ==========================================================

# ==========================================================
# 1. Import Required Libraries
# ==========================================================

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from imblearn.over_sampling import SMOTE

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from sklearn.model_selection import GridSearchCV

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    roc_curve
)

import warnings
warnings.filterwarnings("ignore")


# ==========================================================
# 2. Load Dataset
# ==========================================================

df = pd.read_excel("Dataset for Data Analytics.xlsx")


# ==========================================================
# 3. Display First Five Rows
# ==========================================================

print("First Five Records")
display(df.head())


# ==========================================================
# 4. Display Last Five Rows
# ==========================================================

print("Last Five Records")
display(df.tail())


# ==========================================================
# 5. Dataset Shape
# ==========================================================

print("Number of Rows :", df.shape[0])
print("Number of Columns :", df.shape[1])


# ==========================================================
# 6. Dataset Information
# ==========================================================

print("Dataset Information")
df.info()


# ==========================================================
# 7. Column Names
# ==========================================================

print("\nColumn Names\n")
print(df.columns)


# ==========================================================
# 8. Statistical Summary
# ==========================================================

print("\nStatistical Summary")
display(df.describe(include="all"))


# ==========================================================
# 9. Check Missing Values
# ==========================================================

print("\nMissing Values")
print(df.isnull().sum())


# ==========================================================
# 10. Check Duplicate Records
# ==========================================================

print("\nDuplicate Rows :", df.duplicated().sum())


# ==========================================================
# 11. Remove Duplicate Records
# ==========================================================

df.drop_duplicates(inplace=True)

print("Dataset Shape After Removing Duplicates :", df.shape)


# ==========================================================
# 12. Fill Missing Values
# ==========================================================

# Fill categorical columns with mode
for col in df.select_dtypes(include="object").columns:
    df[col].fillna(df[col].mode()[0], inplace=True)

# Fill numerical columns with median
for col in df.select_dtypes(exclude="object").columns:
    df[col].fillna(df[col].median(), inplace=True)

print("\nMissing Values After Cleaning")
print(df.isnull().sum())


# ==========================================================
# 13. Convert Date Column
# ==========================================================

df["Date"] = pd.to_datetime(df["Date"])


# ==========================================================
# 14. Feature Engineering
# ==========================================================

df["Year"] = df["Date"].dt.year
df["Month"] = df["Date"].dt.month
df["Day"] = df["Date"].dt.day
df["WeekDay"] = df["Date"].dt.day_name()

print("\nFeature Engineering Completed")


# ==========================================================
# 15. Create Artificial Fraud Target
# ==========================================================
# Since the dataset has no fraud column,
# we create one using business rules.
# ==========================================================

df["IsFraud"] = 0

df.loc[
(
    (df["TotalPrice"] > df["TotalPrice"].quantile(0.90))
    |
    (df["Quantity"] > df["Quantity"].quantile(0.90))
    |
    (df["ItemsInCart"] > df["ItemsInCart"].quantile(0.90))
    |
    (df["OrderStatus"].isin(["Cancelled", "Returned"]))
),
"IsFraud"
] = 1


# ==========================================================
# 16. Display Fraud Distribution
# ==========================================================

print("\nFraud Distribution")
print(df["IsFraud"].value_counts())


# ==========================================================
# 17. Visualize Fraud Distribution
# ==========================================================

plt.figure(figsize=(6,4))

sns.countplot(
    x="IsFraud",
    data=df
)

plt.title("Fraud Distribution")
plt.xlabel("Fraud")
plt.ylabel("Count")

plt.show()


# ==========================================================
# 18. Display Updated Dataset
# ==========================================================

display(df.head())


# ==========================================================
# PART 1 COMPLETED
# ==========================================================