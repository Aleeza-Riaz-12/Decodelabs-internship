# ==========================================================
# PART 2 : Exploratory Data Analysis (EDA)
# ==========================================================

# ==========================================================
# 1. Check Data Types
# ==========================================================

print("Data Types")
print(df.dtypes)


# ==========================================================
# 2. Check Unique Values
# ==========================================================

print("\nUnique Values in Each Column\n")

for col in df.columns:
    print(f"{col} : {df[col].nunique()}")


# ==========================================================
# 3. Correlation Matrix
# ==========================================================

# Select only numeric columns
numeric_df = df.select_dtypes(include=np.number)

plt.figure(figsize=(12,8))

sns.heatmap(
    numeric_df.corr(),
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title("Correlation Matrix")
plt.show()


# ==========================================================
# 4. Distribution of Total Price
# ==========================================================

plt.figure(figsize=(8,5))

sns.histplot(
    df["TotalPrice"],
    bins=30,
    kde=True
)

plt.title("Distribution of Total Price")
plt.xlabel("Total Price")
plt.ylabel("Frequency")

plt.show()


# ==========================================================
# 5. Distribution of Quantity
# ==========================================================

plt.figure(figsize=(8,5))

sns.histplot(
    df["Quantity"],
    bins=20,
    kde=True
)

plt.title("Distribution of Quantity")
plt.show()


# ==========================================================
# 6. Order Status Count
# ==========================================================

plt.figure(figsize=(8,5))

sns.countplot(
    y=df["OrderStatus"],
    order=df["OrderStatus"].value_counts().index
)

plt.title("Order Status Distribution")
plt.show()


# ==========================================================
# 7. Payment Method Count
# ==========================================================

plt.figure(figsize=(8,5))

sns.countplot(
    y=df["PaymentMethod"],
    order=df["PaymentMethod"].value_counts().index
)

plt.title("Payment Method Distribution")
plt.show()


# ==========================================================
# 8. Referral Source Count
# ==========================================================

plt.figure(figsize=(8,5))

sns.countplot(
    y=df["ReferralSource"],
    order=df["ReferralSource"].value_counts().index
)

plt.title("Referral Source Distribution")
plt.show()


# ==========================================================
# 9. Top 10 Products
# ==========================================================

plt.figure(figsize=(10,5))

df["Product"].value_counts().head(10).plot(kind="bar")

plt.title("Top 10 Products")
plt.xlabel("Product")
plt.ylabel("Count")

plt.xticks(rotation=45)

plt.show()


# ==========================================================
# 10. Boxplot of Total Price
# ==========================================================

plt.figure(figsize=(8,5))

sns.boxplot(
    x=df["TotalPrice"]
)

plt.title("Boxplot of Total Price")

plt.show()


# ==========================================================
# 11. Boxplot of Quantity
# ==========================================================

plt.figure(figsize=(8,5))

sns.boxplot(
    x=df["Quantity"]
)

plt.title("Boxplot of Quantity")

plt.show()


# ==========================================================
# 12. Fraud Distribution by Payment Method
# ==========================================================

plt.figure(figsize=(10,5))

sns.countplot(
    x="PaymentMethod",
    hue="IsFraud",
    data=df
)

plt.title("Fraud by Payment Method")

plt.xticks(rotation=45)

plt.show()


# ==========================================================
# 13. Fraud Distribution by Order Status
# ==========================================================

plt.figure(figsize=(10,5))

sns.countplot(
    x="OrderStatus",
    hue="IsFraud",
    data=df
)

plt.title("Fraud by Order Status")

plt.xticks(rotation=45)

plt.show()


# ==========================================================
# 14. Monthly Orders
# ==========================================================

plt.figure(figsize=(10,5))

sns.countplot(
    x="Month",
    data=df
)

plt.title("Orders by Month")

plt.show()


# ==========================================================
# 15. Fraud Percentage
# ==========================================================

fraud_percentage = (
    df["IsFraud"]
    .value_counts(normalize=True)
    * 100
)

print("Fraud Percentage")
print(fraud_percentage)


# ==========================================================
# 16. Observations
# ==========================================================

print("\nEDA Completed Successfully.")
print("Key observations:")
print("- Dataset cleaned successfully.")
print("- Fraud target created using business rules.")
print("- Distribution of numerical features visualized.")
print("- Categorical variables explored.")
print("- Correlation matrix analyzed.")
print("- Outliers identified using boxplots.")

# ==========================================================
# PART 2 COMPLETED
# ==========================================================